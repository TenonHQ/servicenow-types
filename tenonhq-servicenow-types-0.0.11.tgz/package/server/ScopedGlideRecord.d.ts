import { ScopedGlideElement } from './ScopedGlideElement';
import { ScopedQueryCondition } from './ScopedQueryCondition';
import { GlideDateTime } from './GlideDateTime';
import { ScopedElementDescriptor } from './ScopedElementDescriptor';
import { QueryOperator, GlideRecordOperation } from '../util';

/**
 * Scoped GlideRecord is used for database operations.
 * This interface provides compatibility with ServiceNow London's ScopedGlideRecord
 * while maintaining integration with the @tenonhq/servicenow-types generic system.
 */
interface ScopedGlideRecord {
    readonly sys_created_by: string & ScopedGlideElement;
    readonly sys_created_on: GlideDateTime & ScopedGlideElement;
    readonly sys_id: string & ScopedGlideElement;
    readonly sys_mod_count: number & ScopedGlideElement;
    readonly sys_updated_by: string & ScopedGlideElement;
    readonly sys_updated_on: GlideDateTime & ScopedGlideElement;
    variables: { [name: string]: any };
    [fieldName: string]: any;

    /**
     * Creates an instance of the GlideRecord class for the specified table.
     *
     * @param tableName The table to be used.
     * @example
     *
     * var gr = new GlideRecord('incident');
     */
    new(tableName: string): ScopedGlideRecord;

    /**
     * Adds a filter to return active records.
     *
     * @returns Filter to return active records.
     * @example
     *
     * var inc = new GlideRecord('incident');
     * inc.addActiveQuery();
     * inc.query();
     */
    addActiveQuery(): ScopedQueryCondition;

    /**
     * Adds an encoded query to other queries that may have been set.
     *
     * @param query An encoded query string
     * @example
     *
     * var queryString = "priority=1^ORpriority=2";
     * var gr = new GlideRecord('incident');
     * gr.addEncodedQuery(queryString);
     * gr.query();
     * while (gr.next()) {
     *   gs.addInfoMessage(gr.number);
     * }
     */
    addEncodedQuery(query: string): void;

    /**
     * Applies a pre-defined GlideDBFunctionBuilder object to a record.
     *
     * @param fun A GlideDBFunctionBuilder object that defines a SQL operation.
     * @returns Method does not return a value
     */
    addFunction(fun: string): void;

    /**
     * Adds a filter to return records based on a relationship in a related table.
     *
     * @param joinTable Table name
     * @param primaryField (Optional) If other than sys_id, the primary field
     * @param joinTableField (Optional) If other than sys_id, the field that joins the tables.
     * @returns A filter that lists records where the relationships match.
     */
    addJoinQuery(
        joinTable: string,
        primaryField?: string,
        joinTableField?: string,
    ): ScopedQueryCondition;

    /**
     * A filter that specifies records where the value of the field passed in the parameter is not
     * null.
     *
     * @param fieldName The name of the field to be checked.
     * @returns A filter that specifies records where the value of the field passed in the
     * parameter is not null.
     */
    addNotNullQuery(fieldName: string): ScopedQueryCondition;

    /**
     * Adds a filter to return records where the value of the specified field is null.
     *
     * @param fieldName The name of the field to be checked.
     * @returns The query condition added to the GlideRecord.
     */
    addNullQuery(fieldName: string): ScopedQueryCondition;

    /**
     * Provides the ability to build a request, which when executed, returns the rows from the
     * specified table, that match the request.
     *
     * @param name Table field name.
     * @param value Value on which to query (not case-sensitive).
     * @returns The query condition added to the GlideRecord.
     */
    addQuery(name: string, value: any): ScopedQueryCondition;

    /**
     * Provides the ability to build a request, which when executed, returns the rows from the
     * specified table, that match the request.
     *
     * @param name Table field name.
     * @param operator Query operator.
     * @param value Value on which to query (not case-sensitive).
     * @returns The query condition that was added to the GlideRecord.
     */
    addQuery(name: string, operator: QueryOperator, value: any): ScopedQueryCondition;

    /**
     * Adds a filter to return records using an encoded query string.
     *
     * @param query An encoded query string
     * @returns The query condition added to the GlideRecord.
     */
    addQuery(query: string): ScopedQueryCondition;

    /**
     * Determines if the Access Control Rules, which include the user's roles, permit
     * inserting new records in this table.
     *
     * @returns True if the user's roles permit creation of new records in this
     * table.
     */
    canCreate(): boolean;

    /**
     * Determines if the Access Control Rules, which include the user's roles, permit deleting
     * records in this table.
     *
     * @returns True if the user's roles permit deletions of records in this table.
     */
    canDelete(): boolean;

    /**
     * Determines if the Access Control Rules, which include the user's roles, permit reading
     * records in this table.
     *
     * @returns True if the user's roles permit reading records from this table.
     */
    canRead(): boolean;

    /**
     * Determines if the Access Control Rules, which include the user's roles, permit editing
     * records in this table.
     *
     * @returns True if the user's roles permit writing to records from this table.
     */
    canWrite(): boolean;

    /**
     * Sets a range of rows to be returned by subsequent queries.
     *
     * @param firstRow The first row to include.
     * @param lastRow The last row to include.
     * @param forceCount If true, the getRowCount() method will return all possible records.
     * @returns Method does not return a value
     */
    chooseWindow(firstRow: number, lastRow: number, forceCount?: boolean): void;

    /**
     * Returns the number of milliseconds since January 1, 1970, 00:00:00 GMT for a duration field.
     * Does not require the creation of a GlideDateTime object because the duration field is already a
     * GlideDateTime object.
     *
     * @returns Number of milliseconds since January 1, 1970, 00:00:00 GMT.
     */
    dateNumericValue(): number;

    /**
     * Deletes multiple records that satisfy the query condition.
     */
    deleteMultiple(): void;

    /**
     * Deletes the current record.
     *
     * @returns True if the record was deleted; false if no record was found to delete.
     */
    deleteRecord(): boolean;

    /**
     * Defines a GlideRecord based on the specified expression of 'name = value'.
     *
     * @param name Column name to match (if two arguments are specified), or sys_id (if one is
     * specified)
     * @param [value] Value to match. If value is not specified, then the expression used is
     * 'sys_id = name'.
     * @returns True if one or more matching records was found. False if no matches
     * found.
     */
    get(name: string, value?: string): boolean;

    /**
     * Returns the dictionary attributes for the specified field.
     *
     * @param fieldName Field name for which to return the dictionary attributes
     * @returns Dictionary attributes
     */
    getAttribute(fieldName: string): string;

    /**
     * Returns the table's label.
     *
     * @returns Table's label
     */
    getClassDisplayValue(): string;

    /**
     * Retrieves the display value for the current record.
     *
     * @returns The display value for the current record.
     */
    getDisplayValue(field?: string): string;

    /**
     * Returns the element's descriptor.
     *
     * @returns Element's descriptor
     */
    getED(): ScopedElementDescriptor;

    /**
     * Retrieves the GlideElement object for the specified field.
     *
     * @param columnName Name of the column to get the element from.
     * @returns The GlideElement for the specified column of the current record.
     */
    getElement(columnName: string): ScopedGlideElement;

    /**
     * Returns an array of GlideElements for the current record.
     *
     * @returns The array of GlideElements for the current record.
     */
    getElements(): [ScopedGlideElement];

    /**
     * Retrieves the query condition of the current result set as an encoded query string.
     *
     * @returns The encoded query as a string.
     */
    getEncodedQuery(): string;

    /**
     * Returns the field's label.
     *
     * @returns Field's label
     */
    getLabel(): string;

    /**
     * Retrieves the last error message. If there is no last error message, null is returned.
     *
     * @returns The last error message as a string.
     */
    getLastErrorMessage(): string;

    /**
     * Retrieves a link to the current record.
     *
     * @param noStack If true, the sysparm_stack parameter is not appended to the link.
     * The parameter sysparm_stack specifies the page to visit after closing the current link.
     * @returns A link to the current record as a string.
     */
    getLink(noStack: boolean): string;

    /**
     * Retrieves the class name for the current record.
     *
     * @returns The class name.
     */
    getRecordClassName(): string;

    /**
     * Retrieves the number of rows in the query result.
     *
     * @returns The number of rows.
     */
    getRowCount(): number;

    /**
     * Retrieves the name of the table associated with the GlideRecord.
     *
     * @returns The table name
     */
    getTableName(): string;

    /**
     * Gets the primary key of the record, which is usually the sys_id unless otherwise
     * specified.
     *
     * @returns The unique primary key as a String, or null if the key is null.
     */
    getUniqueValue(): string;

    /**
     * Retrieves the string value of an underlying element in a field.
     *
     * @param name The name of the field to get the value from.
     * @returns The value of the field.
     */
    getValue(name: string): string | null;

    /**
     * Retrieves a reference to the GlideRecord for a reference field.
     * 
     * @returns A GlideRecord object for the referenced record, or null if the reference is empty.
     */
    getRefRecord(): ScopedGlideRecord | null;

    /**
     * Determines if there are any more records in the GlideRecord object.
     *
     * @returns True if there are more records in the query result set.
     */
    hasNext(): boolean;

    /**
     * Creates an empty record suitable for population before an insert.
     */
    initialize(): void;

    /**
     * Inserts a new record using the field values that have been set for the current record.
     *
     * @returns Unique ID of the inserted record, or null if the record is not inserted.
     */
    insert(): string;

    /**
     * Checks to see if the current database action is to be aborted.
     *
     * @returns True if the current database action is to be aborted
     */
    isActionAborted(): boolean;

    /**
     * Checks if the current record is a new record that has not yet been inserted into the database.
     *
     * @returns True if the record is new and has not been inserted into the database.
     */
    isNewRecord(): boolean;

    /**
     * Determines if the table exists.
     *
     * @returns True if table is valid or if record was successfully retrieved. False if table is
     * invalid or record was not successfully retrieved.
     */
    isValid(): boolean;

    /**
     * Determines if the specified field is defined in the current table.
     *
     * @param columnName The name of the the field.
     * @returns True if the field is defined for the current table.
     */
    isValidField(columnName: string): boolean;

    /**
     * Determines if current record is a valid record.
     *
     * @returns True if the current record is valid. False if past the end of the record set.
     */
    isValidRecord(): boolean;

    /**
     * Creates a new GlideRecord record, sets the default values for the fields, and assigns a unique
     * ID to the record.
     */
    newRecord(): void;

    /**
     * Moves to the next record in the GlideRecord object.
     *
     * @returns True if moving to the next record is successful. False if there are no more records in
     * the result set.
     */
    next(): boolean;

    /**
     * Retrieves the current operation being performed, such as insert, update, or delete.
     *
     * @returns The current operation.
     */
    operation(): GlideRecordOperation;

    /**
     * Specifies an orderBy column.
     *
     * @param name The column name used to order the records in this GlideRecord object.
     */
    orderBy(name: string): void;

    /**
     * Specifies a decending orderBy column.
     *
     * @param name The column name to be used to order the records in a GlideRecord object.
     */
    orderByDesc(name: string): void;

    /**
     * Runs the query against the table based on the filters specified by addQuery, addEncodedQuery,
     * etc.
     *
     * This queries the GlideRecord table as well as any references of the table. Usually this is
     * performed without arguments. If name/value pair is specified, "name=value" condition is added
     * to the query.
     *
     * @param field The column name to query on.
     * @param value The value to query for.
     */
    query(field?: string, value?: any): void;

    /**
     * Sets a flag to indicate if the next database action (insert, update, delete) is to be aborted.
     * This is often used in business rules.
     *
     * @param b True to abort the next action. False if the action is to be allowed.
     */
    setAbortAction(b: boolean): void;

    /**
     * Sets the limit for number of records are fetched by the GlideRecord query.
     *
     * @param maxNumRecords The maximum number of records to fetch.
     */
    setLimit(maxNumRecords: number): void;

    /**
     * Sets sys_id value for the current record.
     *
     * @param guid The GUID to be assigned to the current record.
     */
    setNewGuidValue(guid: string): void;

    /**
     * Sets the value of the field with the specified name to the specified value.
     *
     * @param name Name of the field.
     * @param value The value to assign to the field.
     */
    setValue(name: string, value: any): void;

    /**
     * Enables or disables the running of business rules, script engines, and audit.
     *
     * @param enable If true (default), enables business rules. If false, disables business
     * rules.
     */
    setWorkflow(enable: boolean): void;

    /**
     * Updates the GlideRecord with any changes that have been made. If the record does not already
     * exist, it is inserted.
     *
     * @param [reason] The reason for the update. The reason is displayed in the audit record.
     * @returns Unique ID of the new or updated record. Returns null if the update fails.
     */
    update(reason?: string): string;

    /**
     * Updates each GlideRecord in the list with any changes that have been made.
     */
    updateMultiple(): void;

    /**
     * Moves to the next record in the GlideRecord. Provides the same functionality as next(), it is
     * intended to be used in cases where the GlideRecord has a column named next.
     *
     * @returns True if there are more records in the query set.
     */
    _next(): boolean;

    /**
     * Identical to query(). This method is intended to be used on tables where there is a column
     * named query, which would interfere with using the query() method.
     *
     * @param name Column name on which to query
     * @param value Value for which to query
     */
    _query(name?: string, value?: any): void;
}

/**
 * Constructor interface for creating ScopedGlideRecord instances
 */
interface ScopedGlideRecordConstructor {
    new(tableName: string): ScopedGlideRecord;
}

export { ScopedGlideRecord, ScopedGlideRecordConstructor };